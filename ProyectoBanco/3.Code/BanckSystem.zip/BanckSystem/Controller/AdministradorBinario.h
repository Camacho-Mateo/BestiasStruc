#ifndef ADMINISTRADORBINARIO_H
#define ADMINISTRADORBINARIO_H

#include <string>

using namespace std;

struct Movimiento {
    string cedula;
    string tipoMovimiento;
    double monto;
    string fecha;
    double saldoFinal;
};

class AdministradorBinario {
public:
    void registrarMovimiento(const string& cedula, const string& tipoMovimiento, double monto, const string& fecha, double saldoFinal);
};

#endif