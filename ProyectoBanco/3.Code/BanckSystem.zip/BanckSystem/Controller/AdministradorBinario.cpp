#include "AdministradorBinario.h"
#include <fstream>
#include <iostream>

void AdministradorBinario::registrarMovimiento(const string& cedula, const string& tipoMovimiento, double monto, const string& fecha, double saldoFinal) {
    ofstream archivo("movimientos.bin", ios::binary | ios::app);
    if (!archivo) {
        cerr << "Error al abrir el archivo binario para registrar movimiento." << endl;
        return;
    }

    Movimiento mov;
    mov.cedula = cedula;
    mov.tipoMovimiento = tipoMovimiento;
    mov.monto = monto;
    mov.fecha = fecha;
    mov.saldoFinal = saldoFinal;

    size_t tamCedula = mov.cedula.size();
    size_t tamTipo = mov.tipoMovimiento.size();
    size_t tamFecha = mov.fecha.size();

    archivo.write(reinterpret_cast<char*>(&tamCedula), sizeof(tamCedula));
    archivo.write(mov.cedula.c_str(), tamCedula);

    archivo.write(reinterpret_cast<char*>(&tamTipo), sizeof(tamTipo));
    archivo.write(mov.tipoMovimiento.c_str(), tamTipo);

    archivo.write(reinterpret_cast<char*>(&mov.monto), sizeof(mov.monto));

    archivo.write(reinterpret_cast<char*>(&tamFecha), sizeof(tamFecha));
    archivo.write(mov.fecha.c_str(), tamFecha);

    archivo.write(reinterpret_cast<char*>(&mov.saldoFinal), sizeof(mov.saldoFinal));

    archivo.close();
}
